
# CallFox Render A+ version
Готовая версия для загрузки в Render + GitHub.
Настрой:
 - environment variables
 - webhooks CryptoCloud + Telegram
Запуск: npm install && npm start
